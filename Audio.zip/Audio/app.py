import streamlit as st
import numpy as np
import librosa
import tensorflow as tf
from tensorflow.keras.models import load_model
from sklearn.preprocessing import LabelEncoder

# Load the trained model
model = load_model(r'E:\final notebook\Notebooks\Audio\cnn_audio_model.h5')

# Define the class names and their corresponding indices
class_names = {
    0: 'sadness',
    1: 'fear',
    2: 'disgust',
    3: 'joy',
    4: 'surprise',
    5: 'neutral',
    6: 'anger'
}

# Load the label encoder classes
try:
    label_encoder_classes = np.load(r'E:\final notebook\Notebooks\Audio\label_encoder_classes.npy')
    label_encoder = LabelEncoder()
    label_encoder.classes_ = label_encoder_classes
except FileNotFoundError:
    st.error("Label encoder file not found. Make sure 'label_encoder_classes.npy' is present.")
    st.stop()

# Function to extract audio features using Librosa
def extract_audio_features(audio_path):
    try:
        y, sr = librosa.load(audio_path, sr=None)
        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        mfccs_processed = np.mean(mfccs.T, axis=0)  # Taking the mean across time
        return mfccs_processed
    except Exception as e:
        st.error(f"Error extracting features from {audio_path}: {str(e)}")
        return None

# Streamlit app
st.title("Emotion Prediction from Audio")

# File uploader
uploaded_file = st.file_uploader("Upload an audio file", type=["wav", "mp3"])

if uploaded_file is not None:
    # Extract audio features
    features = extract_audio_features(uploaded_file)
    
    if features is not None:
        # Prepare the features for prediction
        features = np.expand_dims(features, axis=0)  # Add batch dimension
        features = np.expand_dims(features, axis=-1)  # Add channel dimension if needed
        
        # Predict emotion
        predictions = model.predict(features)
        predicted_class = np.argmax(predictions, axis=1)[0]
        predicted_emotion = class_names.get(predicted_class, "Unknown")
        
        st.write(f"Predicted Emotion: {predicted_emotion}")
    else:
        st.write("Could not extract features from the audio file.")
