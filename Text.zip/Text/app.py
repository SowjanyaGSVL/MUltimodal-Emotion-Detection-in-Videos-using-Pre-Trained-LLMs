import streamlit as st
import torch
import torch.nn as nn
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.preprocessing import LabelEncoder
import pickle

# Define the LSTM model class (same as before)
class LSTMModel(nn.Module):
    def __init__(self, vocab_size, embed_size, hidden_size, num_layers, num_classes):
        super(LSTMModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_size)
        self.lstm = nn.LSTM(embed_size, hidden_size, num_layers=num_layers, batch_first=True, bidirectional=True)
        self.dropout = nn.Dropout(0.5)
        self.fc = nn.Linear(hidden_size * 2, num_classes)

    def forward(self, x):
        x = self.embedding(x)
        x, _ = self.lstm(x)
        x = self.dropout(x[:, -1, :])
        x = self.fc(x)
        return x

# Load the trained model
def load_model():
    vocab_size = st.session_state['vocab_size']
    embed_size = st.session_state['embed_size']
    hidden_size = st.session_state['hidden_size']
    num_layers = st.session_state['num_layers']
    num_classes = st.session_state['num_classes']

    model = LSTMModel(vocab_size, embed_size, hidden_size, num_layers, num_classes)
    model.load_state_dict(torch.load(r'E:\final notebook\Notebooks\Text\text_lstm_emotion_model.pth', map_location=torch.device('cpu')))
    model.eval()
    return model

# Preprocess the input text
def preprocess_text(text, tokenizer, max_len):
    seq = tokenizer.texts_to_sequences([text])
    padded_seq = pad_sequences(seq, maxlen=max_len)
    return torch.tensor(padded_seq, dtype=torch.long)

# Predict emotion
def predict_emotion(text, model, tokenizer, max_len, label_encoder):
    input_tensor = preprocess_text(text, tokenizer, max_len)
    output = model(input_tensor)
    predicted_label = torch.argmax(output, dim=1).item()
    emotion = label_encoder.inverse_transform([predicted_label])[0]
    return emotion

# Streamlit app
def main():
    st.title("Emotion Detection from Text")
    
    # User input
    user_input = st.text_area("Enter text to predict emotion:")
    
    if st.button("Predict"):
        # Load tokenizer and other necessary data
        tokenizer = st.session_state['tokenizer']
        max_len = st.session_state['max_len']
        label_encoder = st.session_state['label_encoder']
        
        # Load the model
        model = load_model()
        
        # Predict the emotion
        emotion = predict_emotion(user_input, model, tokenizer, max_len, label_encoder)
        
        st.write(f"Predicted Emotion: **{emotion}**")

# Session state setup (to keep track of necessary components)
if 'vocab_size' not in st.session_state:
    # Load your saved tokenizer, label encoder, and any other necessary data here
    with open(r'E:\final notebook\Notebooks\Text\tokenizer.pkl', 'rb') as f:
        st.session_state['tokenizer'] = pickle.load(f)

    with open(r'E:\final notebook\Notebooks\Text\label_encoder.pkl', 'rb') as f:
        st.session_state['label_encoder'] = pickle.load(f)

    st.session_state['vocab_size'] = len(st.session_state['tokenizer'].word_index) + 1
    st.session_state['embed_size'] = 100
    st.session_state['hidden_size'] = 128
    st.session_state['num_layers'] = 2
    st.session_state['num_classes'] = len(st.session_state['label_encoder'].classes_)
    st.session_state['max_len'] = 100  # Update this with your actual max sequence length

if __name__ == "__main__":
    main()
